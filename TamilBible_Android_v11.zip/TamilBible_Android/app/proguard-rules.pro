# Keep WebView JS interfaces
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
# Keep MainActivity
-keep class com.tamilbible.app.** { *; }
