# பரிசுத்த வேதாகமம் — Tamil Bible Android App

A full-featured Tamil + English Bible app (31,102 verses) built as a native Android WebView APK.

---

## 📁 Project Structure

```
TamilBible_Android/
├── .github/
│   └── workflows/
│       └── build.yml          ← GitHub Actions — auto-builds APK on every push
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   ├── index.html     ← App entry point
│   │   │   ├── css/style.css  ← All UI styles
│   │   │   └── js/
│   │   │       ├── data-tm.js     ← Tamil Bible text (4.5 MB)
│   │   │       ├── data-en.js     ← English KJV text (4.1 MB)
│   │   │       ├── data-order.js  ← Book list + names
│   │   │       └── app.js         ← All features & logic
│   │   ├── java/com/tamilbible/app/
│   │   │   └── MainActivity.java
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/ (strings, colors, styles)
│   │   │   └── mipmap-*/ic_launcher.png
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradlew
└── gradlew.bat
```

---

## 🚀 How to Get Your APK (Free, No PC needed)

### Step 1 — Create GitHub account
Go to **github.com** → Sign up (free)

### Step 2 — Create a new repository
1. Click **+** → **New repository**
2. Name: `tamil-bible` (or anything you like)
3. Set to **Private** (your Bible data stays yours)
4. Click **Create repository**

### Step 3 — Upload this project
**Option A — GitHub website (easiest on mobile):**
1. In your new repo, click **Add file → Upload files**
2. Drag and drop the entire `TamilBible_Android` folder contents
3. Make sure the folder structure is preserved:
   - `.github/workflows/build.yml` must be at the root level
   - `app/` folder at root level
   - `build.gradle`, `settings.gradle` at root level
4. Click **Commit changes**

**Option B — GitHub Desktop (PC):**
1. Download GitHub Desktop from desktop.github.com
2. Clone your repo → copy all files → commit → push

### Step 4 — GitHub Actions builds automatically
1. Go to your repo → click **Actions** tab
2. You'll see **"Build Tamil Bible APK"** workflow running
3. Wait ~5–8 minutes for it to finish
4. Click the completed run → scroll to **Artifacts** section
5. Download **TamilBible-Debug-APK** → unzip → get the `.apk` file

### Step 5 — Install on your phone
1. Transfer the `.apk` to your Android phone
2. Open phone **Settings → Security → Install unknown apps** → enable for your browser/file manager
3. Tap the APK file → Install
4. App appears as **பரிசுத்த வேதாகமம்** with a Bible icon

---

## ✍️ App Features
- 📖 Full Tamil Bible (31,102 verses) — works **offline**
- 🌐 English KJV alongside every verse
- 🔄 Global Tamil/English toggle (switches entire UI + verse order)
- 🔍 Search across all 31,102 verses in Tamil or English
- ♥ Favourites — save and revisit verses
- ✓ Mark as Read — track reading progress
- 📌 Pin verses
- 📋 Custom verse lists with copy/share
- 📸 Image share — generates a beautiful verse card image
- 🎯 Reading goal (1 year / 1 month / custom)
- 📖 Story mode — auto-advance verses
- ❓ Quiz — Tamil or English
- 🎨 Verse colour, background & font size customisation
- Back button navigates within the app

---

## 🔐 Optional: Signed Release APK (for Play Store)

A signed APK is needed to publish on Google Play Store.

### Generate a keystore (one-time setup):
```bash
keytool -genkey -v -keystore tamil-bible-release.jks \
  -alias tamilbible -keyalg RSA -keysize 2048 -validity 10000
```

### Add secrets to GitHub:
1. Go to your repo → **Settings → Secrets and variables → Actions**
2. Add these 4 secrets:

| Secret name | Value |
|---|---|
| `KEYSTORE_BASE64` | Run: `base64 -i tamil-bible-release.jks` → paste output |
| `KEYSTORE_PASSWORD` | The password you set when generating the keystore |
| `KEY_ALIAS` | `tamilbible` (or whatever alias you used) |
| `KEY_PASSWORD` | The key password (same as keystore password if you used one) |

3. Push any change to trigger a new build
4. Download **TamilBible-Release-APK** from Actions artifacts

---

## ⚙️ APK Details
| Property | Value |
|---|---|
| Package | `com.tamilbible.app` |
| Min Android | 5.0 (API 21) |
| Target Android | 14 (API 34) |
| Estimated APK size | ~9–10 MB |
| Offline | ✅ Full offline — all data embedded |
| localStorage | ✅ Favourites, goals, settings persist |

---

## 🛠️ Troubleshooting

**Build fails with "SDK not found"**
→ GitHub Actions installs the SDK automatically. If it fails, re-run the workflow.

**App shows white/blank screen**
→ Make sure all 4 JS files are in `app/src/main/assets/js/`

**Fonts look wrong**
→ The app needs internet on first launch to load Google Fonts (Latha). After that it's cached.

**Actions tab not showing the workflow**
→ Make sure `build.yml` is in `.github/workflows/` at the root of your repo (not inside a subfolder).
